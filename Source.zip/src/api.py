# src/api.py
from fastapi import FastAPI
from src.trainer import AdvancedTrainer

app = FastAPI()
trainer = AdvancedTrainer(access_level='sai_2')  # Gunakan SAI 2 secara default

@app.post("/api/run")
async def run_query(query: str):
    result = {"query": query}
    def callback(response):
        result["response"] = response
    trainer.run(query, callback)
    while "response" not in result:
        pass
    return result

@app.get("/api/status")
async def check_status():
    return {"status": "running", "model": "SAI 2"}