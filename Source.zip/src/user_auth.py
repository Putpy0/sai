# src/user_auth.py
class UserAuth:
    def __init__(self):
        # Tidak ada autentikasi, hapus konfigurasi file users.json dan credentials
        pass

    def authenticate(self):
        # Tidak ada autentikasi, kembalikan None atau default
        return None

    def register_user(self, creds):
        # Tidak diperlukan
        return "default_user"

    def check_access(self, user_id):
        # Selalu izinkan akses untuk mode pribadi
        return True

    def upgrade_plan(self, user_id, payment_method):
        # Tidak diperlukan untuk saat ini
        return False