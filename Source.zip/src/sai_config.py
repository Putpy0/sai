# src/sai_config.py
SAI_CONFIG = {
    'sai_2': {
        'max_batch_size': 8,
        'max_seq_len': 4096 * 4,
        'dtype': 'fp8',
        'vocab_size': 102400,
        'dim': 2048,
        'inter_dim': 10944,
        'moe_inter_dim': 1408,
        'n_layers': 27,
        'n_dense_layers': 1,
        'n_heads': 16,
        'n_routed_experts': 'dynamic',
        'n_shared_experts': 2,
        'n_activated_experts': 6,
        'n_expert_groups': 1,
        'n_limited_groups': 1,
        'score_func': 'softmax',
        'route_scale': 1.0,
        'q_lora_rank': 0,
        'kv_lora_rank': 512,
        'qk_nope_head_dim': 128,
        'qk_rope_head_dim': 64,
        'v_head_dim': 128,
        'original_seq_len': 4096,
        'rope_theta': 10000.0,
        'rope_factor': 40,
        'beta_fast': 32,
        'beta_slow': 1,
        'mscale': 1.0
    }
}