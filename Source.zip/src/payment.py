import requests

class PaymentProcessor:
    def __init__(self):
        self.dana_url = "https://api.dana.id/v1/payment"
        self.gopay_url = "https://api.gopay.com/v1/payment"
        self.api_key = "your_api_key_here"

    def process_payment(self, user_id, amount, method):
        if method == 'dana':
            payload = {"user_id": user_id, "amount": amount, "description": "Upgrade to SAI 2"}
            response = requests.post(self.dana_url, json=payload, headers={'Authorization': f'Bearer {self.api_key}'})
        elif method == 'gopay':
            payload = {"user_id": user_id, "amount": amount, "description": "Upgrade to SAI 2"}
            response = requests.post(self.gopay_url, json=payload, headers={'Authorization': f'Bearer {self.api_key}'})
        else:
            return False
        return response.status_code == 200