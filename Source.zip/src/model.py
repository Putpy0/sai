import tensorflow as tf
from tensorflow.keras import layers
import math

class RMSNorm(layers.Layer):
    def __init__(self, dim, eps=1e-6):
        super(RMSNorm, self).__init__()
        self.dim = dim
        self.eps = eps
        self.weight = tf.Variable(tf.ones([dim]), name='weight')

    def call(self, x):
        variance = tf.reduce_mean(tf.square(x), axis=-1, keepdims=True)
        x_norm = x * tf.math.rsqrt(variance + self.eps)
        return self.weight * x_norm

class Linear(layers.Layer):
    def __init__(self, in_features, out_features, bias=False, dtype=tf.bfloat16):
        super(Linear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = tf.Variable(tf.random.normal([out_features, in_features], dtype=dtype), name='weight')
        if bias:
            self.bias = tf.Variable(tf.zeros([out_features], dtype=dtype), name='bias')
        else:
            self.bias = None

    def call(self, x):
        output = tf.matmul(x, self.weight, transpose_b=True)
        if self.bias is not None:
            output += self.bias
        return output

class DeepSeekTransformer(layers.Layer):
    def __init__(self, args):
        super(DeepSeekTransformer, self).__init__()
        self.args = args
        self.n_routed_experts = args['n_routed_experts'] if isinstance(args['n_routed_experts'], int) else 32
        self.layers = [TransformerLayer(args) for _ in range(args['n_layers'])]
        self.norm = RMSNorm(args['dim'])

    def add_expert(self):
        for layer in self.layers:
            layer.moe.add_expert()
        self.n_routed_experts += 1

    def call(self, x, start_pos, freqs_cis, mask):
        for layer in self.layers:
            x = layer(x, start_pos, freqs_cis, mask)
        return self.norm(x)

class TransformerLayer(layers.Layer):
    def __init__(self, args):
        super(TransformerLayer, self).__init__()
        self.attn_norm = RMSNorm(args['dim'])
        self.ffn_norm = RMSNorm(args['dim'])
        self.mla = MLA(args)
        self.moe = MoE(args)

    def call(self, x, start_pos, freqs_cis, mask):
        h = x + self.mla(self.attn_norm(x), start_pos, freqs_cis, mask)
        out = h + self.moe(self.ffn_norm(h))
        return out

class MoE(layers.Layer):
    def __init__(self, args):
        super(MoE, self).__init__()
        self.n_routed_experts = args['n_routed_experts'] if isinstance(args['n_routed_experts'], int) else 32
        self.n_activated_experts = args['n_activated_experts']
        self.experts = [FeedForward(args) for _ in range(self.n_routed_experts)]
        self.gate = Linear(args['dim'], self.n_routed_experts)

    def add_expert(self):
        self.experts.append(FeedForward(self.args))
        self.n_routed_experts += 1
        self.gate = Linear(self.args['dim'], self.n_routed_experts)

    def call(self, x):
        gates = tf.nn.softmax(self.gate(x), axis=-1)
        top_k_values, top_k_indices = tf.math.top_k(gates, k=self.n_activated_experts)
        expert_outputs = [expert(x) for expert in self.experts]
        output = tf.zeros_like(expert_outputs[0])
        for i in range(self.n_activated_experts):
            indices = top_k_indices[:, :, i]
            values = top_k_values[:, :, i:i+1]
            expert_output = tf.gather(expert_outputs, indices, batch_dims=0)
            output += values * expert_output
        return output

class FeedForward(layers.Layer):
    def __init__(self, args):
        super(FeedForward, self).__init__()
        self.args = args
        self.w1 = Linear(args['dim'], args['moe_inter_dim'])
        self.w2 = Linear(args['moe_inter_dim'], args['dim'])
        self.w3 = Linear(args['dim'], args['moe_inter_dim'])

    def call(self, x):
        return self.w2(tf.nn.gelu(self.w1(x)) * self.w3(x))

class MLA(layers.Layer):
    def __init__(self, args):
        super(MLA, self).__init__()
        self.args = args
        self.n_heads = args['n_heads']
        self.qk_head_dim = args['qk_nope_head_dim'] + args['qk_rope_head_dim']
        self.v_head_dim = args['v_head_dim']
        if args['q_lora_rank'] == 0:
            self.wq = Linear(args['dim'], self.n_heads * self.qk_head_dim)
        else:
            self.wq_a = Linear(args['dim'], args['q_lora_rank'])
            self.q_norm = RMSNorm(args['q_lora_rank'])
            self.wq_b = Linear(args['q_lora_rank'], self.n_heads * self.qk_head_dim)
        self.wkv_a = Linear(args['dim'], args['kv_lora_rank'] + args['qk_rope_head_dim'])
        self.kv_norm = RMSNorm(args['kv_lora_rank'])
        self.wkv_b = Linear(args['kv_lora_rank'], self.n_heads * (args['qk_nope_head_dim'] + self.v_head_dim))
        self.wo = Linear(self.n_heads * self.v_head_dim, args['dim'])
        self.softmax_scale = self.qk_head_dim ** -0.5
        if args['max_seq_len'] > args['original_seq_len']:
            mscale = 0.1 * args['mscale'] * math.log(args['rope_factor']) + 1.0
            self.softmax_scale = self.softmax_scale * mscale * mscale

        self.kv_cache = tf.Variable(tf.zeros([args['max_batch_size'], args['max_seq_len'], args['kv_lora_rank']]), trainable=False)
        self.pe_cache = tf.Variable(tf.zeros([args['max_batch_size'], args['max_seq_len'], args['qk_rope_head_dim']]), trainable=False)

    def call(self, x, start_pos, freqs_cis, mask):
        bsz, seqlen, _ = x.shape
        end_pos = start_pos + seqlen

        if self.args['q_lora_rank'] == 0:
            q = self.wq(x)
        else:
            q = self.wq_b(self.q_norm(self.wq_a(x)))
        q = tf.reshape(q, [bsz, seqlen, self.n_heads, self.qk_head_dim])
        q_nope, q_pe = tf.split(q, [self.args['qk_nope_head_dim'], self.args['qk_rope_head_dim']], axis=-1)
        q_pe = self._apply_rotary_emb(q_pe, freqs_cis)

        kv = self.wkv_a(x)
        kv, k_pe = tf.split(kv, [self.args['kv_lora_rank'], self.args['qk_rope_head_dim']], axis=-1)
        k_pe = self._apply_rotary_emb(tf.expand_dims(k_pe, 2), freqs_cis)

        self.kv_cache[:bsz, start_pos:end_pos].assign(self.kv_norm(kv))
        self.pe_cache[:bsz, start_pos:end_pos].assign(tf.squeeze(k_pe, 2))

        wkv_b = self.wkv_b.weight
        wkv_b = tf.reshape(wkv_b, [self.n_heads, -1, self.args['kv_lora_rank']])
        q_nope = tf.einsum('bshd,hdc->bshc', q_nope, wkv_b[:, :self.args['qk_nope_head_dim']])
        scores = (tf.einsum('bshc,btc->bsht', q_nope, self.kv_cache[:bsz, :end_pos]) +
                  tf.einsum('bshd,btd->bsht', q_pe, self.pe_cache[:bsz, :end_pos]))
        scores = scores * self.softmax_scale
        scores = scores + (1.0 - mask) * -1e9

        attn = tf.nn.softmax(scores, axis=-1)
        v = tf.einsum('bshc,hdc->bshd', self.kv_cache[:bsz, :end_pos], wkv_b[:, self.args['qk_nope_head_dim']:])
        output = tf.einsum('bsht,bthd->bshd', attn, v)
        output = tf.reshape(output, [bsz, seqlen, self.n_heads * self.v_head_dim])
        return self.wo(output)

    def _apply_rotary_emb(self, x, freqs_cis):
        x = tf.cast(x, tf.float32)
        x = tf.reshape(x, [*x.shape[:-1], -1, 2])
        x = tf.complex(x[..., 0], x[..., 1])
        freqs_cis = tf.reshape(freqs_cis, [1, x.shape[1], 1, x.shape[-1]])
        y = x * freqs_cis
        y = tf.stack([tf.math.real(y), tf.math.imag(y)], axis=-1)
        y = tf.reshape(y, [*y.shape[:-2], -1])
        return tf.cast(y, x.dtype)