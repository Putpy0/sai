from transformers import BertTokenizer

class AdvancedTokenizer:
    def __init__(self):
        self.tokenizer = BertTokenizer.from_pretrained('bert-base-multilingual-cased', vocab_size=102400)

    def tokenize(self, text):
        return self.tokenizer(text, return_tensors='tf', padding=True, truncation=True, max_length=4096 * 4)

    def decode(self, token_ids):
        return self.tokenizer.decode(token_ids, skip_special_tokens=True)