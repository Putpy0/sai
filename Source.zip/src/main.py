# src/main.py
import argparse
from src.trainer import AdvancedTrainer
import time

def main():
    parser = argparse.ArgumentParser(description="SAI AI System")
    parser.add_argument('--mode', choices=['train_and_run', 'convert'], required=True)
    parser.add_argument('--hf-ckpt-path', type=str, default=None, help="Path to Hugging Face checkpoint (for convert mode)")
    parser.add_argument('--save-path', type=str, default="storage/model_0001/", help="Path to save converted model")
    parser.add_argument('--n-experts', type=int, default=64, help="Number of experts for conversion")
    parser.add_argument('--model-parallel', type=int, default=4, help="Model parallelism for conversion")
    args = parser.parse_args()

    # Gunakan SAI 2 sebagai default untuk mode pribadi
    trainer = AdvancedTrainer(access_level='sai_2')

    if args.mode == 'train_and_run':
        trainer.train_and_run()
        while True:
            query = input("Masukkan pertanyaan (atau 'exit'): ")
            if query.lower() == 'exit':
                trainer.stop()
                break
            def print_response(response):
                print(f"Jawaban: {response}")
            trainer.run(query, print_response)
            time.sleep(1)
    elif args.mode == 'convert':
        if not args.hf_ckpt_path:
            print("Harap masukkan --hf-ckpt-path untuk mode convert!")
            return
        from src.convert import convert_model
        convert_model(args.hf_ckpt_path, args.save_path, args.n_experts, args.model_parallel)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nProses dihentikan.")