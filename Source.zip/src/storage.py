import os
import sqlite3
from pathlib import Path

class DataStorage:
    def __init__(self, db_path='storage/db/datasets.db', base_path='datasets', model_path='storage'):
        self.db_path = db_path
        self.base_path = Path(base_path)
        self.model_path = Path(model_path)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.create_tables()
        self.model_version = 1

    def create_tables(self):
        with self.conn:
            self.conn.execute('''
                CREATE TABLE IF NOT EXISTS datasets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path TEXT NOT NULL,
                    size INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

    def prepare_dataset(self, source_data):
        dataset_path = self.base_path
        dataset_path.mkdir(parents=True, exist_ok=True)
        file_idx = len(list(dataset_path.glob('data_*.txt'))) + 1
        current_size = 0
        current_file = None
        max_size = 4 * 1024 * 1024 * 1024  # 4GB

        for chunk in source_data:
            if current_size >= max_size or current_file is None:
                if current_file:
                    current_file.close()
                    self.add_file(file_path, current_size)
                file_path = dataset_path / f"data_{file_idx}.txt"
                current_file = file_path.open('w')
                current_size = 0
                file_idx += 1
            current_file.write(chunk)
            current_size += len(chunk.encode('utf-8'))
        if current_file:
            current_file.close()
            self.add_file(file_path, current_size)

    def add_file(self, file_path, size):
        with self.conn:
            self.conn.execute(
                'INSERT INTO datasets (file_path, size) VALUES (?, ?)',
                (str(file_path), size)
            )

    def load_dataset(self):
        cursor = self.conn.execute('SELECT file_path FROM datasets')
        return [Path(row[0]).read_text() for row in cursor.fetchall()]

    def save_model(self, model, version=None):
        if version is None:
            version = self.model_version
            self.model_version += 1
        model_path = self.model_path / f"model_{version:04d}"
        model.save(str(model_path), save_format='tf', shard_size_bytes=1*1024*1024*1024)
        print(f"Model disimpan di {model_path}")

    def convert_checkpoint(self, hf_ckpt_path, n_experts, mp):
        from src.convert import convert_model
        convert_model(hf_ckpt_path, self.model_path, n_experts, mp)