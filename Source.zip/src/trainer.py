# src/trainer.py
import tensorflow as tf
from tensorflow.keras import layers, Model
from src.tokenizer import AdvancedTokenizer
from src.storage import DataStorage
from src.sai_config import SAI_CONFIG
from src.model import DeepSeekTransformer
import threading
import queue
import time
import logging
import os
from datetime import datetime

def setup_logging():
    os.makedirs('logs', exist_ok=True)
    log_file = f"logs/sai_2_{datetime.now().strftime('%Y-%m-%d')}.log"
    logging.basicConfig(filename=log_file, level=logging.INFO, format='%(asctime)s - %(message)s')
    return logging.getLogger()

class SAIModel(Model):
    def __init__(self):
        super(SAIModel, self).__init__()
        self.tokenizer = AdvancedTokenizer()
        self.args = SAI_CONFIG['sai_2']  # Gunakan konfigurasi SAI 2
        self.embedding = layers.Embedding(self.args['vocab_size'], self.args['dim'])
        self.transformer = DeepSeekTransformer(self.args)
        self.lm_head = layers.Dense(self.args['vocab_size'])

    def add_expert(self):
        self.transformer.add_expert()
        print(f"Expert ditambah, total: {self.transformer.n_routed_experts}")

    def call(self, inputs, start_pos=0):
        embeddings = self.embedding(inputs)
        freqs_cis = self._precompute_freqs_cis()
        mask = tf.ones((tf.shape(inputs)[0], self.args['max_seq_len']), dtype=tf.float32)
        mask = tf.linalg.band_part(mask, -1, 0) - tf.eye(tf.shape(inputs)[1])
        output = self.transformer(embeddings, start_pos, freqs_cis, mask)
        return self.lm_head(output)

    def _precompute_freqs_cis(self):
        dim = self.args['qk_rope_head_dim']
        seqlen = self.args['max_seq_len']
        beta_fast = self.args['beta_fast']
        beta_slow = self.args['beta_slow']
        base = self.args['rope_theta']
        factor = self.args['rope_factor']

        freqs = 1.0 / (base ** (tf.range(0, dim, 2, dtype=tf.float32) / dim))
        if seqlen > self.args['original_seq_len']:
            low, high = self._find_correction_range(beta_fast, beta_slow, dim, base, self.args['original_seq_len'])
            smooth = 1 - tf.clip_by_value((tf.range(dim // 2, dtype=tf.float32) - low) / (high - low), 0, 1)
            freqs = freqs / factor * (1 - smooth) + freqs * smooth

        t = tf.range(seqlen, dtype=tf.float32)
        freqs = tf.einsum('i,j->ij', t, freqs)
        freqs_cis = tf.complex(tf.ones_like(freqs), freqs)
        return freqs_cis

    def _find_correction_range(self, low_rot, high_rot, dim, base, max_seq_len):
        low = tf.floor(dim * tf.math.log(max_seq_len / (low_rot * 2 * math.pi)) / (2 * tf.math.log(base)))
        high = tf.ceil(dim * tf.math.log(max_seq_len / (high_rot * 2 * math.pi)) / (2 * tf.math.log(base)))
        return tf.maximum(low, 0), tf.minimum(high, dim - 1)

class AdvancedTrainer:
    def __init__(self):
        self.model = SAIModel()
        self.storage = DataStorage()
        self.optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
        self.loss_fn = tf.keras.losses.SparseCategoricalCrossentropy()
        self.query_queue = queue.Queue()
        self.running = False
        self.logger = setup_logging()

    def train_step(self, inputs, labels):
        with tf.GradientTape() as tape:
            predictions = self.model(inputs, start_pos=0)
            loss = self.loss_fn(labels, predictions)
        gradients = tape.gradient(loss, self.model.trainable_variables)
        self.optimizer.apply_gradients(zip(gradients, self.model.trainable_variables))
        return loss

    def train_and_run(self):
        self.running = True
        self.logger.info("Memulai pelatihan SAI 2...")
        dataset = self.storage.load_dataset()
        self.logger.info(f"Dataset yang dimuat: {len(dataset)} file")
        tokenized_data = [self.model.tokenizer.tokenize(d) for d in dataset]
        input_ids = tf.concat([d['input_ids'] for d in tokenized_data], axis=0)
        labels = input_ids[:, 1:]

        def train_loop():
            batch_size = 16
            idx = 0
            while self.running:
                start = idx * batch_size
                end = min((idx + 1) * batch_size, len(input_ids))
                if start >= len(input_ids):
                    idx = 0
                    start, end = 0, batch_size
                batch_inputs = input_ids[start:end, :-1]
                batch_labels = labels[start:end]
                loss = self.train_step(batch_inputs, batch_labels)
                idx += 1
                if idx % 100 == 0:
                    self.storage.save_model(self.model)
                    self.logger.info(f"Batch {idx}, Loss: {loss.numpy()}")
                if idx % 200 == 0:
                    self.model.add_expert()
                    self.logger.info(f"Expert ditambah, total: {self.model.transformer.n_routed_experts}")

        def inference_loop():
            while self.running:
                try:
                    query, callback = self.query_queue.get(timeout=1)
                    inputs = self.model.tokenizer.tokenize(query)['input_ids']
                    outputs = self.model(inputs, start_pos=0)
                    response = self.model.tokenizer.decode(tf.argmax(outputs, axis=-1))
                    self.logger.info(f"Query: {query}, Response: {response}")
                    callback(response)
                except queue.Empty:
                    time.sleep(0.1)

        train_thread = threading.Thread(target=train_loop)
        inference_thread = threading.Thread(target=inference_loop)
        train_thread.start()
        inference_thread.start()
        self.logger.info("Melatih dan menjalankan SAI 2...")

    def run(self, query, callback):
        self.query_queue.put((query, callback))

    def stop(self):
        self.running = False
        self.logger.info("Proses pelatihan dihentikan.")